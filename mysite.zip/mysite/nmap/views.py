from django.shortcuts import render
from django.http import HttpResponse
import json
from . import xml2db as Xml
# Create your views here.
#templates/nmap/index.html is error.
def index(request):
  return render(request,'nmap/index.html')

def scan_data(request):
#得到xml文件
#  Xml.output_xml()
#得到xml文件的根节点
  node_root=Xml.output_node_root()
#得到主机的存活数量
  live_hosts=Xml.output_live_host(node_root)
#得到扫描时间
  run_time=Xml.output_run_time(node_root)
#得到各个操作系统的数量
  (windows_num,linux_num,router_num,others)=Xml.output_os_num(node_root)
#返回json数据到前端
  json_data={
  'live_hosts':live_hosts,
  'windows_num':windows_num,
  'linux_num':linux_num,
  'router_num':router_num,
  'run_time':run_time,
  'others':others
  }
  json_str=json.dumps(json_data)
  return HttpResponse(json_str,content_type='application/json')

def get_xml(request):
  xml_str=Xml.output_xml_str()
  return HttpResponse(xml_str,content_type='application/xml')

