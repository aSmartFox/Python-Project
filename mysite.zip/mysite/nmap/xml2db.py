import xml.etree.ElementTree as ET
import os

# '''为views.py 提供可用的函数'''
# 得到xml文件
def output_xml():
  state=os.system("nmap  -sS -P0 -sV -O  172.18.146.0/24 -oX result.xml")
  return state

# 得到xml树和根节点
def output_node_root():
  tree=ET.parse('result.xml')
  node_root=tree.getroot()
  return node_root

# 得到xml文件读取之后的字符串
def output_xml_str():
  xml_str=open('result.xml','r+',encoding='utf-8').read()
  return xml_str



# 得到主机存活数量
def output_live_host(node_root):
  runstats=node_root.find('runstats')
  hosts=runstats.find('hosts')
  return hosts.attrib['up'] 

# 得到程序运行时间
def output_run_time(node_root):
  runstats=node_root.find('runstats')
  finished=runstats.find('finished')
  return finished.attrib['elapsed']


# 得到各个操作系统的数量
def output_os_num(node_root):
  host_list = node_root.findall('host')
  windows_num = 0
  linux_num = 0
  router_num = 0
  others = 0
  for host in host_list:
    os=host.find('os')
    osmatch=os.find('osmatch')
    if(not osmatch):
      others = others + 1
    else:
      osmatch_name=osmatch.attrib['name']
      osmatch_name_lower=osmatch_name.lower()
#     print(osmatch_name_lower)
      if(osmatch_name_lower.find('windows')!=-1):
        windows_num=windows_num+1
      elif(osmatch_name_lower.find('linux')!=-1):
        linux_num=linux_num+1
      else:
        router_num=router_num+1
  return windows_num,linux_num,router_num,others






 

