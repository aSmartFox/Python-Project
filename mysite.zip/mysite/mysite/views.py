# coding:utf-8
from django.http import HttpResponse
       
def hello(request):
  return HttpResponse("Hello world! this is my first website trail ,hdl,好好学习")

def add(request):
  a = request.GET['a']
  b = request.GET['b']
  c=int(a)+int(b)
  return HttpResponse(str(c))
