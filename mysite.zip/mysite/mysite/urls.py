"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import *
from mysite import views as mysite_views
from nmap import views as nmap_views
from django.contrib import admin

#urlpatterns = [
#   url(r'^admin/', include(admin.site.urls)),
#]
urlpatterns =[ 
    url(r'^admin/',admin.site.urls),
    url(r'^hello/$',mysite_views.hello),
    url(r'^add/$',mysite_views.add),
    url(r'^index/$',nmap_views.index),
    url(r'^scan_data/$',nmap_views.scan_data),
    url(r'^get_xml/$',nmap_views.get_xml),
#    url(r'^ajax_Linux_numbers/$',nmap_views.ajax_Linux_numbers),
#    url(r'^ajax_Windows_numbers/$',nmap_views.ajax_Windows_numbers),
#    url(r'^ajax_router_numbers/$',nmap_views.ajax_router_numbers),
#    url(r'^ajax_scan_content/$',nmap_views.ajax_scan_content),
#    url(r'^ajax_run_time/$',nmap_views.ajax_run_time),
#    url(r'^ajax_nmap/$',nmap_views.ajax_nmap),
]
